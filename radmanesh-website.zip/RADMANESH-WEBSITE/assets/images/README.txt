Put profile.jpg (your photo) and project/gallery images here, then set their paths in js/config.js
