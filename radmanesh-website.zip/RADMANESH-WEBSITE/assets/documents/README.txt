Put resume.pdf here, then set resume: "assets/documents/resume.pdf" in js/config.js
