/* RADMANESH — central config. Edit text, links, projects here. Everything is bilingual: {en, fa}. */
const CONFIG = {
  defaultLang: "en",            // "en" or "fa"
  email: "",                    // your email, e.g. "name@example.com" (enables the contact form's email draft)
  social: { telegram: "", linkedin: "", instagram: "", tiktok: "" }, // paste full URLs
  text: {
    en: {
      nav:{about:"About",journey:"Journey",skills:"Skills",projects:"Projects",education:"Education",vision:"Vision",insights:"Insights",contact:"Contact"},
      hero:{eyebrow:"Sayed Omid Radmanesh",l1:"Think Beyond Limits.",l2:"Build. Lead. Create.",sub:"A journey of ambition, learning, entrepreneurship and meaningful impact.",b1:"Explore My World",b2:"Get In Touch"},
      about:{eyebrow:"About Me",h:"Beyond a Name. A Journey.",
        p1:"I am a Finance & Banking student at Balkh University, driven by curiosity about how business, economics and good management create real opportunities for people.",
        p2:"I believe in continuous learning, personal growth and building things that last — and I am working step by step toward becoming a skilled professional and an independent entrepreneur.",
        facts:["Sayed Omid Radmanesh","📍 Mazar-e Sharif, Afghanistan","🎓 Balkh University — Economics","💼 Business · Finance · Leadership"]},
      journey:{eyebrow:"My Journey",h:"Every Step Builds the Future."},
      skills:{eyebrow:"Skills & Expertise",h:"Skills That Shape My Future."},
      projects:{eyebrow:"Projects & Ventures",h:"Ideas Into Action.",view:"View Details",visit:"Visit Project",nolink:"Link not added yet — set it in js/config.js."},
      education:{eyebrow:"Education & Certifications",h:"Knowledge Is an Investment."},
      vision:{eyebrow:"Vision & Philosophy",h:"The Future Is Built, Not Waited For."},
      insights:{eyebrow:"Insights & Thoughts",h:"Ideas Worth Sharing."},
      contact:{eyebrow:"Contact",h:"Let's Create Something Meaningful.",p:"Open to conversations about business, learning and collaboration.",name:"Name",email:"Email",subject:"Subject",message:"Message",send:"Prepare Message",
        mailto:"Your email app was opened with a draft. The message is NOT sent until you send it there.",nobackend:"This form has no sending service connected yet. Please use the links on the left."},
      footer:"Think Beyond Limits."
    },
    fa: {
      nav:{about:"درباره من",journey:"مسیر",skills:"مهارت‌ها",projects:"پروژه‌ها",education:"تحصیلات",vision:"چشم‌انداز",insights:"نوشته‌ها",contact:"تماس"},
      hero:{eyebrow:"سید امید رادمنش",l1:"فراتر از مرزها بیندیش.",l2:"بساز. رهبری کن. خلق کن.",sub:"سفری از جاه‌طلبی، یادگیری، کارآفرینی و ایجاد تأثیری معنادار.",b1:"جهان من را کشف کنید",b2:"ارتباط با من"},
      about:{eyebrow:"درباره من",h:"فراتر از یک نام. یک مسیر.",
        p1:"من دانشجوی رشته مالی و بانکداری در دانشگاه بلخ هستم و به این موضوع علاقه دارم که تجارت، اقتصاد و مدیریت درست چگونه برای مردم فرصت می‌سازند.",
        p2:"به یادگیری مداوم، رشد فردی و ساختن چیزهای ماندگار باور دارم و قدم‌به‌قدم در مسیر تبدیل‌شدن به یک متخصص توانمند و کارآفرینی مستقل پیش می‌روم.",
        facts:["سید امید رادمنش","📍 مزار شریف، افغانستان","🎓 دانشگاه بلخ — اقتصاد","💼 تجارت · مالی · رهبری"]},
      journey:{eyebrow:"مسیر من",h:"هر گام، آینده را می‌سازد."},
      skills:{eyebrow:"مهارت‌ها و تخصص",h:"مهارت‌هایی که آینده‌ام را شکل می‌دهند."},
      projects:{eyebrow:"پروژه‌ها و فعالیت‌ها",h:"از ایده تا عمل.",view:"مشاهده جزئیات",visit:"مشاهده پروژه",nolink:"لینک هنوز اضافه نشده — در js/config.js تنظیم کنید."},
      education:{eyebrow:"تحصیلات و گواهی‌ها",h:"دانش، یک سرمایه‌گذاری است."},
      vision:{eyebrow:"چشم‌انداز و فلسفه",h:"آینده ساخته می‌شود، نه انتظار."},
      insights:{eyebrow:"دیدگاه‌ها و نوشته‌ها",h:"ایده‌هایی که ارزش گفتن دارند."},
      contact:{eyebrow:"تماس",h:"بیایید چیزی معنادار بسازیم.",p:"آماده گفتگو درباره تجارت، یادگیری و همکاری هستم.",name:"نام",email:"ایمیل",subject:"موضوع",message:"پیام",send:"آماده‌سازی پیام",
        mailto:"برنامه ایمیل شما با یک پیش‌نویس باز شد. پیام تا زمانی که در آن‌جا ارسال نکنید، فرستاده نمی‌شود.",nobackend:"این فرم هنوز به سرویس ارسال متصل نیست. لطفاً از لینک‌های کنار آن استفاده کنید."},
      footer:"فراتر از مرزها بیندیش."
    }
  },
  // Add new steps by copying a line:
  timeline: [
    {en:"Graduated from school with excellent academic results",fa:"فارغ‌التحصیل مکتب با نتایج تحصیلی عالی"},
    {en:"Experience teaching mathematics",fa:"تجربه تدریس ریاضی"},
    {en:"Active in an educational environment, supporting administrative work",fa:"فعالیت در محیط آموزشی و همکاری در امور اداری"},
    {en:"Experience communicating with students and managing interactions",fa:"تجربه ارتباط با دانش‌آموزان و مدیریت تعاملات"},
    {en:"Began Finance & Banking at Balkh University",fa:"ورود به رشته مالی و بانکداری در دانشگاه بلخ"},
    {en:"Started business-related activities and venture development",fa:"شروع فعالیت‌های مرتبط با تجارت و توسعه کسب‌وکار"}
  ],
  skills: [
    {icon:"◆",t:{en:"Business & Management",fa:"کسب‌وکار و مدیریت"},items:["Business Development","Communication","Relationship Building","Leadership Development","Sales & Negotiation"]},
    {icon:"◈",t:{en:"Finance & Economics",fa:"مالی و اقتصاد"},items:["Financial Knowledge","Banking Fundamentals","Economic Analysis","Financial Learning"]},
    {icon:"▣",t:{en:"Digital Skills",fa:"مهارت‌های دیجیتال"},items:["Microsoft Excel","Microsoft Word","PowerPoint","Canva","CapCut","Digital Content Creation","AI-Assisted Tools"]},
    {icon:"✦",t:{en:"Teaching & Communication",fa:"تدریس و ارتباط"},items:["Mathematics Teaching","Presentation","Public Speaking Development","Educational Support"]}
  ],
  projects: [
    {art:"a1",cat:{en:"Business Network",fa:"شبکه کسب‌وکار"},title:"REPOINT",link:"",
      desc:{en:"Introducing a business project, building connections, growing a network and helping people understand its business model. No profit or financial guarantees are claimed.",fa:"معرفی یک پروژه تجاری، ایجاد ارتباطات، توسعه شبکه و آشنایی افراد با مدل کسب‌وکار آن. هیچ سود تضمینی یا تأیید مالی ادعا نمی‌شود."}},
    {art:"a2",cat:{en:"Digital Tools",fa:"ابزارهای دیجیتال"},title:"ALPHA FALCONS HUB",link:"",
      desc:{en:"Designing and developing digital tools for management, education, planning and improving team activities.",fa:"طراحی و توسعه ابزارهای دیجیتال برای مدیریت، آموزش، برنامه‌ریزی و بهبود فعالیت‌های تیمی."}},
    {art:"a3",cat:{en:"Experiments",fa:"تجربه‌ها"},title:"PERSONAL DIGITAL PROJECTS",link:"",
      desc:{en:"Experience in web page design, practical tools, digital content creation and using AI technologies.",fa:"تجربه در طراحی صفحات وب، ابزارهای کاربردی، تولید محتوای دیجیتال و استفاده از فناوری‌های هوش مصنوعی."}}
  ],
  education: [
    {icon:"🎓",t:{en:"Balkh University",fa:"دانشگاه بلخ"},d:{en:"Faculty of Economics — Finance & Banking (in progress)",fa:"دانشکده اقتصاد — مالی و بانکداری (در حال تحصیل)"}},
    {icon:"💻",t:{en:"Computer Course",fa:"دوره کامپیوتر"},d:{en:"Certificate details to be added",fa:"جزئیات گواهی بعداً افزوده می‌شود"}},
    {icon:"∑",t:{en:"Mathematics Teaching",fa:"تدریس ریاضی"},d:{en:"Practical teaching experience",fa:"تجربه عملی تدریس"}}
  ],
  vision: [
    {en:"Become a professional in finance and trade.",fa:"تبدیل‌شدن به یک متخصص حرفه‌ای در حوزه مالی و تجارت."},
    {en:"Grow management and leadership strength.",fa:"توسعه توانایی‌های مدیریتی و رهبری."},
    {en:"Build independent businesses.",fa:"ایجاد کسب‌وکارهای مستقل."},
    {en:"Sharpen communication and public speaking.",fa:"توسعه مهارت‌های ارتباطی و سخنرانی."},
    {en:"Create economic value and opportunity for others.",fa:"ایجاد ارزش اقتصادی و فرصت برای دیگران."},
    {en:"Keep learning. Keep growing.",fa:"یادگیری و رشد مداوم."}
  ],
  // Demo posts — replace with your own. Delete the "demo" flag for real posts.
  posts: [
    {demo:true,cat:{en:"Business",fa:"تجارت"},t:{en:"Sample: Why small steps compound",fa:"نمونه: چرا گام‌های کوچک انباشته می‌شوند"},x:{en:"A placeholder post. Replace with your own writing.",fa:"یک نوشته نمایشی. با نوشته خودتان جایگزین کنید."}},
    {demo:true,cat:{en:"Finance",fa:"مالی"},t:{en:"Sample: Reading a balance sheet",fa:"نمونه: خواندن ترازنامه"},x:{en:"A placeholder post. Replace with your own writing.",fa:"یک نوشته نمایشی. با نوشته خودتان جایگزین کنید."}},
    {demo:true,cat:{en:"Personal Development",fa:"توسعه فردی"},t:{en:"Sample: Habits of lifelong learners",fa:"نمونه: عادت‌های یادگیرندگان همیشگی"},x:{en:"A placeholder post. Replace with your own writing.",fa:"یک نوشته نمایشی. با نوشته خودتان جایگزین کنید."}}
  ]
};

/* ===== SECTION 2 — Site structure & extra content (edit freely) ===== */
CONFIG.theme = "dark";                                   // "dark" or "light" (visitors can switch)
CONFIG.resume = "";                                      // e.g. "assets/documents/resume.pdf" — empty hides the button
CONFIG.sections = ["about","journey","skills","projects","education","interests","vision","insights","gallery","contact"]; // ORDER of sections
CONFIG.hidden = [];                                      // hide sections, e.g. ["gallery","interests"]
CONFIG.stats = [];                                       // verified numbers only, e.g. [{n:"3",l:{en:"Projects",fa:"پروژه"}}]
CONFIG.profile = { image:"assets/images/profile.jpg", shape:"portrait", /* "portrait" or "square" */
  title:{en:"Finance & Banking Student · Aspiring Entrepreneur",fa:"دانشجوی مالی و بانکداری · کارآفرین آینده‌نگر"},
  loc:{en:"Mazar-e Sharif, Afghanistan",fa:"مزار شریف، افغانستان"} };
const M=(l,k,o)=>Object.assign(CONFIG.text[l][k]||(CONFIG.text[l][k]={}),o);
M("en","nav",{interests:"Interests",gallery:"Gallery"});M("fa","nav",{interests:"علایق",gallery:"گالری"});
CONFIG.text.en.hero={name:"Sayed Omid Radmanesh",tag:"Think Beyond Limits. Build Your Future.",quote:"Driven by curiosity, shaped by learning, and focused on building meaningful opportunities.",b1:"Discover My Journey",b2:"Explore My Work",b3:"Contact Me",resume:"Download Résumé"};
CONFIG.text.fa.hero={name:"سید امید رادمنش",tag:"فراتر از مرزها بیندیش. آینده‌ات را بساز.",quote:"با کنجکاوی هدایت می‌شوم، با یادگیری شکل می‌گیرم و بر ساختن فرصت‌های معنادار تمرکز دارم.",b1:"سفر من را ببینید",b2:"کارهای من",b3:"تماس با من",resume:"دانلود رزومه"};
M("en","about",{h:"Who I Am.",p1:"I'm a Finance & Banking student at Balkh University with a strong interest in business, economics, management and entrepreneurship.",p2:"I've taught mathematics and worked in educational settings, and I enjoy technology, continuous learning and professional communication. I'm building my path one step at a time.",facts:["Sayed Omid Radmanesh","📍 Mazar-e Sharif, Afghanistan","🎓 Finance & Banking — Balkh University","💡 Technology · Learning · Leadership"]});
M("fa","about",{h:"من کیستم.",p1:"من دانشجوی مالی و بانکداری در دانشگاه بلخ هستم و به تجارت، اقتصاد، مدیریت و کارآفرینی علاقه‌ای جدی دارم.",p2:"تجربه تدریس ریاضی و فعالیت در محیط‌های آموزشی دارم و به فناوری، یادگیری مداوم و ارتباطات حرفه‌ای علاقه‌مندم. مسیرم را قدم‌به‌قدم می‌سازم.",facts:["سید امید رادمنش","📍 مزار شریف، افغانستان","🎓 مالی و بانکداری — دانشگاه بلخ","💡 فناوری · یادگیری · رهبری"]});
M("en","journey",{h:"The Journey So Far."});M("fa","journey",{h:"مسیری که تاکنون آمده‌ام."});
M("en","skills",{h:"What I Bring to the Table."});M("fa","skills",{h:"آنچه با خود می‌آورم."});
M("en","projects",{h:"What I'm Building."});M("fa","projects",{h:"آنچه می‌سازم."});
M("en","education",{h:"Education & Learning."});M("fa","education",{h:"تحصیل و یادگیری."});
M("en","interests",{eyebrow:"Beyond Work",h:"Beyond Work."});M("fa","interests",{eyebrow:"فراتر از کار",h:"فراتر از کار."});
M("en","vision",{h:"Building Tomorrow."});M("fa","vision",{h:"ساختن فردا."});
M("en","insights",{h:"Thoughts, Ideas & Insights."});M("fa","insights",{h:"افکار، ایده‌ها و دیدگاه‌ها."});
M("en","gallery",{eyebrow:"Gallery & Media",h:"Moments & Media."});M("fa","gallery",{eyebrow:"گالری و رسانه",h:"لحظه‌ها و تصاویر."});
M("en","contact",{h:"Let's Connect."});M("fa","contact",{h:"بیایید ارتباط بگیریم."});
CONFIG.text.en.ui={search:"Search…",all:"All",none:"Nothing found.",read:"Read",share:"Share",copied:"Link copied",ph:"Placeholder"};
CONFIG.text.fa.ui={search:"جست‌وجو…",all:"همه",none:"موردی یافت نشد.",read:"خواندن",share:"اشتراک‌گذاری",copied:"لینک کپی شد",ph:"نمونه"};
CONFIG.skills=[
 {icon:"◆",t:{en:"Business",fa:"کسب‌وکار"},items:["Business Development","Communication","Relationship Building","Sales","Leadership Development"]},
 {icon:"◈",t:{en:"Finance",fa:"مالی"},items:["Finance & Banking Fundamentals","Economics","Financial Analysis Learning"]},
 {icon:"▣",t:{en:"Digital",fa:"دیجیتال"},items:["Microsoft Office","Canva","CapCut","AI Tools","Digital Content Creation","Web Projects"]},
 {icon:"✦",t:{en:"Education",fa:"آموزش"},items:["Mathematics Teaching","Presentation","Educational Support"]}];
CONFIG.projects=[ // image: "assets/images/xyz.jpg" (optional) · link: project URL (optional)
 {art:"a2",cat:{en:"Digital Tools",fa:"ابزارهای دیجیتال"},title:"ALPHA FALCONS HUB",image:"",link:"",desc:{en:"A digital tool for education, management and planning of team activities.",fa:"ابزاری دیجیتال برای آموزش، مدیریت و برنامه‌ریزی فعالیت‌های تیمی."}},
 {art:"a1",cat:{en:"Business Network",fa:"شبکه کسب‌وکار"},title:"REPOINT",image:"",link:"",desc:{en:"Activity in building connections, introducing a business model and growing a network. No profit guarantees or financial endorsements are claimed.",fa:"فعالیت در توسعه ارتباطات، معرفی مدل کسب‌وکار و توسعه شبکه. هیچ سود تضمینی یا تأیید مالی ادعا نمی‌شود."}},
 {art:"a3",cat:{en:"Creative",fa:"خلاقانه"},title:"DIGITAL CREATIONS",image:"",link:"",desc:{en:"Personal projects in design, technology and digital content creation.",fa:"پروژه‌های شخصی در زمینه طراحی، فناوری و تولید محتوای دیجیتال."}}];
CONFIG.interests=[{icon:"🚀",t:{en:"Business & Entrepreneurship",fa:"تجارت و کارآفرینی"}},{icon:"📈",t:{en:"Financial Markets",fa:"بازارهای مالی"}},{icon:"🤖",t:{en:"Technology & AI",fa:"فناوری و هوش مصنوعی"}},{icon:"📚",t:{en:"Books & Learning",fa:"کتاب و یادگیری"}},{icon:"🧭",t:{en:"Leadership",fa:"رهبری"}},{icon:"🎤",t:{en:"Communication & Public Speaking",fa:"ارتباطات و سخنرانی"}},{icon:"🎨",t:{en:"Creative Projects",fa:"پروژه‌های خلاق"}}];
CONFIG.vision=[{en:"Become a professional in finance and trade.",fa:"تبدیل‌شدن به متخصص حرفه‌ای در حوزه مالی و تجارت."},{en:"Build independent businesses.",fa:"ایجاد کسب‌وکارهای مستقل."},{en:"Grow in management and leadership.",fa:"رشد در مدیریت و رهبری."},{en:"Deepen financial analysis skills.",fa:"رشد در حوزه تحلیل مالی."},{en:"Strengthen public speaking.",fa:"تقویت مهارت سخنرانی."},{en:"Create valuable opportunities for others.",fa:"ایجاد فرصت‌های ارزشمند برای دیگران."}];
CONFIG.posts=[ // demo:true shows the Demo badge — remove it for your real posts. body: use \n for new paragraphs
 {demo:true,cat:{en:"Business",fa:"تجارت"},t:{en:"Sample: Why small steps compound",fa:"نمونه: چرا گام‌های کوچک انباشته می‌شوند"},x:{en:"A placeholder post.",fa:"یک نوشته نمایشی."},body:{en:"This is a demo post. Replace it with your own writing.\nUse \\n for a new paragraph.",fa:"این یک نوشته نمایشی است. آن را با نوشته خودتان جایگزین کنید.\nبرای پاراگراف جدید از \\n استفاده کنید."}},
 {demo:true,cat:{en:"Finance",fa:"مالی"},t:{en:"Sample: Reading a balance sheet",fa:"نمونه: خواندن ترازنامه"},x:{en:"A placeholder post.",fa:"یک نوشته نمایشی."},body:{en:"Demo content only — not a real article.",fa:"فقط محتوای نمایشی — مقاله واقعی نیست."}},
 {demo:true,cat:{en:"Personal Development",fa:"توسعه فردی"},t:{en:"Sample: Habits of lifelong learners",fa:"نمونه: عادت‌های یادگیرندگان همیشگی"},x:{en:"A placeholder post.",fa:"یک نوشته نمایشی."},body:{en:"Demo content only — not a real article.",fa:"فقط محتوای نمایشی — مقاله واقعی نیست."}}];
CONFIG.gallery=[1,2,3,4,5,6].map(i=>({img:"",cap:{en:"Placeholder "+i,fa:"نمونه "+i}})); // img: "assets/images/photo1.jpg"
