(()=>{const C=CONFIG,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let lang,theme;try{lang=localStorage.lang;theme=localStorage.theme}catch(e){}lang=lang||C.defaultLang;theme=theme||C.theme;
const F={p:{c:"",q:""},o:{c:"",q:""}};let T,U;const sec=()=>C.sections.filter(s=>!C.hidden.includes(s));
const hd=id=>`<p class="eyebrow">${T[id].eyebrow}</p><h2>${T[id].h}</h2>`,L=o=>o[lang],ini="SOR";
const img=(s,a)=>s?`<img src="${s}" alt="${a}" loading="lazy" onerror="this.remove()">`:"";
const soc=()=>Object.entries(C.social).map(([k,u])=>{const n=k[0].toUpperCase()+k.slice(1);return u?`<a href="${u}" target="_blank" rel="noopener">${n}</a>`:`<span title="js/config.js">${n}</span>`}).join("")+(C.email?`<a href="mailto:${C.email}">Email</a>`:`<span title="js/config.js">Email</span>`);
const chips=(k,l)=>{const m=new Map();l.forEach(x=>m.set(x.cat.en,L(x.cat)));return `<div class="fl"><input type="search" data-q="${k}" placeholder="${U.search}" aria-label="${U.search}"><button class="chip on" data-k="${k}" data-f="">${U.all}</button>${[...m].map(([e,t])=>`<button class="chip" data-k="${k}" data-f="${e}">${t}</button>`).join("")}</div>`};
const S={
about:()=>`<div class="two"><div><p>${T.about.p1}</p><p>${T.about.p2}</p></div><div class="bento">${T.about.facts.map(f=>`<div class="glass reveal">${f}</div>`).join("")}</div></div>`,
journey:()=>`<ol class="tl">${C.timeline.map(x=>`<li class="reveal"><p>${L(x)}</p></li>`).join("")}</ol>`,
skills:()=>`<div class="grid4">${C.skills.map(s=>`<article class="card glass reveal"><i>${s.icon}</i><h3>${L(s.t)}</h3><ul>${s.items.map(i=>`<li>${i}</li>`).join("")}</ul></article>`).join("")}</div>`,
projects:()=>(C.stats.length?`<div class="stats">${C.stats.map(s=>`<div><b>${s.n}</b>${L(s.l)}</div>`).join("")}</div>`:"")+chips("p",C.projects)+`<div class="grid3" id="pl"></div>`,
education:()=>`<div class="grid3">${C.education.map(e=>`<article class="card glass reveal"><i>${e.icon}</i><h3>${L(e.t)}</h3><p>${L(e.d)}</p></article>`).join("")}</div>`,
interests:()=>`<div class="grid4">${C.interests.map(e=>`<div class="card glass int reveal"><i>${e.icon}</i><h3>${L(e.t)}</h3></div>`).join("")}</div>`,
vision:()=>`<ul class="vis">${C.vision.map(v=>`<li class="reveal">${L(v)}</li>`).join("")}</ul>`,
insights:()=>chips("o",C.posts)+`<div class="grid3" id="ol"></div>`,
gallery:()=>`<div class="gal">${C.gallery.map((g,i)=>`<button class="gi reveal" data-g="${i}" aria-label="${L(g.cap)}"><div class="ph"><span>${ini[0]}</span><small>${L(g.cap)}</small></div>${img(g.img,L(g.cap))}</button>`).join("")}</div>`,
contact:()=>`<div class="two"><div><p>${T.contact.p}</p><div class="soc">${soc()}</div></div><form id="cf" class="glass"><label><span>${T.contact.name}</span><input name="name" required autocomplete="name"></label><label><span>${T.contact.email}</span><input name="email" type="email" required autocomplete="email"></label><label><span>${T.contact.subject}</span><input name="subject" required></label><label><span>${T.contact.message}</span><textarea name="message" rows="4" required></textarea></label><button class="btn pri">${T.contact.send}</button><p id="fm" role="status"></p></form></div>`};
const pcard=(p,i)=>`<article class="card glass reveal"><div class="art ${p.art}">${img(p.image,p.title)}</div><span class="tag">${L(p.cat)}</span><h3>${p.title}</h3><p>${L(p.desc).split(".")[0]}.</p><button class="btn" data-p="${i}">${T.projects.view}</button></article>`;
const ocard=(p,i)=>`<article class="card glass post reveal"><span class="tag">${L(p.cat)}${p.demo?'<span class="demo">Demo</span>':""}</span><h3>${L(p.t)}</h3><p>${L(p.x)}</p><button class="btn" data-o="${i}">${U.read}</button></article>`;
function fill(k){const el=$("#"+k+"l");if(!el)return;const l=k==="p"?C.projects:C.posts,f=F[k];
el.innerHTML=l.map((x,i)=>[x,i]).filter(([x])=>(!f.c||x.cat.en===f.c)&&JSON.stringify(x).toLowerCase().includes(f.q)).map(([x,i])=>k==="p"?pcard(x,i):ocard(x,i)).join("")||`<p>${U.none}</p>`;obs()}
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}}),{threshold:.1});
const obs=()=>$$(".reveal:not(.in)").forEach(e=>io.observe(e));
function render(){T=C.text[lang];U=T.ui;const h=document.documentElement,P=C.profile,H=T.hero;h.lang=lang;h.dir=lang==="fa"?"rtl":"ltr";h.dataset.theme=theme;
$("#lang").textContent=lang==="fa"?"EN":"فارسی";$("#menu").innerHTML=sec().map(s=>`<a href="#${s}">${T.nav[s]}</a>`).join("");
$("#hero").innerHTML=`<div class="scene" aria-hidden="true"><i class="orb o1"></i><i class="orb o2"></i><i class="ring r1"></i><i class="ring r2"></i></div><div class="wrap hg"><div class="hero-t"><p class="eyebrow">${H.name}</p><h1>RADMANESH</h1><p class="big grad">${H.tag}</p><p class="quote">${H.quote}</p><div class="btns"><a class="btn pri" href="#journey">${H.b1}</a><a class="btn" href="#projects">${H.b2}</a><a class="btn" href="#contact">${H.b3}</a>${C.resume?`<a class="btn" href="${C.resume}" download>${H.resume}</a>`:""}</div></div><div><div class="frame ${P.shape==="square"?"square":""}"><div class="ph"><span>${ini}</span></div>${img(P.image,H.name)}</div><div class="cap"><b>${H.name}</b><small>${L(P.title)}</small><br><small>📍 ${L(P.loc)}</small></div></div></div>`;
$("#main").innerHTML=sec().map(s=>`<section id="${s}" class="wrap">${hd(s)}${S[s]()}</section>`).join("");fill("p");fill("o");obs();clock()}
const clock=()=>$("#clock").textContent=new Date().toLocaleString(lang==="fa"?"fa-AF":"en-GB",{dateStyle:"medium",timeStyle:"medium"});setInterval(clock,1000);
const open=h=>{$("#dm").innerHTML=h;$("#dlg").showModal()};
function share(i){const u=location.href.split("#")[0]+"#post-"+i,t=L(C.posts[i].t);if(navigator.share)navigator.share({title:t,url:u}).catch(()=>{});else navigator.clipboard?.writeText(u).then(()=>alert(U.copied))}
function openP(i){const p=C.projects[i];open(`<p class="eyebrow">${L(p.cat)}</p><h3>${p.title}</h3><p>${L(p.desc)}</p>${p.link?`<a class="btn pri" target="_blank" rel="noopener" href="${p.link}">${T.projects.visit}</a>`:`<p class="note">${T.projects.nolink}</p>`}`)}
function openO(i){const p=C.posts[i];history.replaceState(null,"","#post-"+i);open(`<p class="eyebrow">${L(p.cat)}${p.demo?'<span class="demo">Demo</span>':""}</p><h3>${L(p.t)}</h3><div class="post">${L(p.body).split("\n").map(x=>`<p>${x}</p>`).join("")}</div><button class="btn share" data-s="${i}">${U.share}</button>`)}
document.addEventListener("click",e=>{const t=e.target;let b;
if(b=t.closest("[data-f]")){const k=b.dataset.k;F[k].c=b.dataset.f;$$(`.chip[data-k="${k}"]`).forEach(c=>c.classList.toggle("on",c===b));fill(k)}
else if(b=t.closest("[data-p]"))openP(+b.dataset.p);else if(b=t.closest("[data-o]"))openO(+b.dataset.o);
else if(b=t.closest("[data-s]"))share(+b.dataset.s);
else if(b=t.closest("[data-g]")){const g=C.gallery[b.dataset.g];open(`<div class="lg"><div class="ph"><span>${ini}</span><small>${L(g.cap)}</small></div>${img(g.img,L(g.cap))}</div>`)}
else if(t.closest("#dx")||t.id==="dlg")$("#dlg").close()});
document.addEventListener("input",e=>{const k=e.target.dataset.q;if(k){F[k].q=e.target.value.toLowerCase();fill(k)}});
$("#dlg").addEventListener("close",()=>{if(location.hash.startsWith("#post-"))history.replaceState(null,"",location.pathname)});
document.addEventListener("submit",e=>{if(e.target.id!=="cf")return;e.preventDefault();const f=e.target,T2=T.contact;
if(C.email){location.href=`mailto:${C.email}?subject=${encodeURIComponent(f.subject.value)}&body=${encodeURIComponent(f.message.value+"\n\n— "+f.name.value+" ("+f.email.value+")")}`;$("#fm").textContent=T2.mailto}else $("#fm").textContent=T2.nobackend});
$("#lang").onclick=()=>{lang=lang==="en"?"fa":"en";try{localStorage.lang=lang}catch(e){}render()};
$("#theme").onclick=()=>{theme=theme==="dark"?"light":"dark";try{localStorage.theme=theme}catch(e){}document.documentElement.dataset.theme=theme};
$("#burger").onclick=e=>{e.currentTarget.setAttribute("aria-expanded",$("#menu").classList.toggle("open"))};
$("#menu").onclick=e=>{if(e.target.tagName==="A"){$("#menu").classList.remove("open");$("#burger").setAttribute("aria-expanded",false)}};
function onScroll(){const h=document.documentElement,y=h.scrollTop;$("#bar").style.transform=`scaleX(${y/(h.scrollHeight-h.clientHeight||1)})`;$("#top").classList.toggle("show",y>700);
let cur="";$$("main section").forEach(s=>{if(s.offsetTop-120<=y)cur=s.id});$$("#menu a").forEach(a=>a.classList.toggle("act",a.hash==="#"+cur))}
addEventListener("scroll",onScroll,{passive:true});$("#top").onclick=()=>scrollTo({top:0,behavior:"smooth"});
if(matchMedia("(pointer:fine)").matches&&!matchMedia("(prefers-reduced-motion:reduce)").matches){const c=$("#cur");
addEventListener("mousemove",e=>{c.style.opacity=1;c.style.transform=`translate(${e.clientX-7}px,${e.clientY-7}px)`;const s=$(".scene");if(s)s.style.transform=`translate(${(e.clientX/innerWidth-.5)*-24}px,${(e.clientY/innerHeight-.5)*-24}px)`});
document.addEventListener("mouseover",e=>c.style.scale=e.target.closest("a,button,.card,.gi")?2.4:1)}
$("#yr").textContent=new Date().getFullYear();render();onScroll();
const m=location.hash.match(/^#post-(\d+)$/);if(m&&C.posts[m[1]])openO(+m[1]);
addEventListener("load",()=>setTimeout(()=>$("#loader").classList.add("off"),500));})();
